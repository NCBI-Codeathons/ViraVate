# RSV DATASET INFO

From this page: 
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE99298

This file was downloaded: "GSE99298_counts.txt.gz"

The following columns of this file was used for our 2 separate DE runs (both back the controls)

columns 3 & 4 are controls
columns 5-9 & 13-14= mutated infected
columns 10-12 = wild type infected


We tested the mutated infected against the controls and the wild type infected against the controls (same controls) in two separate DE runs

- the mutated version of this virus is turns out to be very similar in expression to the mock controls because the mutation was designed to be ('knockout function'). Therefore, we are only retaining the WT infected vs Control data. 