# HSV1 DATASET INFO

publication:
https://www.nature.com/articles/s41467-018-07944-x#Sec9

From this page: 
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE120891

This file was downloaded: "GSE120891_counts.txt.gz"

1. get information table for each sample from https://www.ncbi.nlm.nih.gov/Traces/study/?acc=PRJNA494846&o=acc_s%3Aa
2. Based on "virus_strain", "source_name" and "hours_post_infection/collection_time" information for each sample, keep subsets with:
    - virus_strain: (1) "HSV1/strain F"; (2) "mock"
    - source_name: (1) "human lung fibroblasts"
    - hours_post_infection/collection_time: (1) 9
As a result, samples/columns named [Mock_9h_1], [Mock_9h_1], [HSV_1], [HSV_2] were kept

3. Also, generate supplemental "group_name" file [GSE120891_counts-HSV1_mock9h_only-group_name.txt] that contains group name of each column(sample) with the same order
    - 2 groups: (1) Mock; (2) HSV1
4. Also, generate supplemental "comparison" file [GSE120891_counts-HSV1_mock9h_only-comparison.txt] that contains 1 pair of comparison