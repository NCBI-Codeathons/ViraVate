# HEPATITIS E DATASET INFO

publication:
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3910912/

From this page: 
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE105414

This file was downloaded: "GSE88731_160826_RNASeq_Feng_unfiltered_de.xlsx.gz"



(infected with kernow C1 P6 strain)

- 4 replicate controls ('mocks' = not infected) "M5_1-4"
- 4 replicate infected testsets - "5_1-4"

the raw counts were taken from the above noted columns


