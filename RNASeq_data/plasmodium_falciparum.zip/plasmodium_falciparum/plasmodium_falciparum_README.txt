# Plasmodium falciparum DATASET INFO

From this page: 
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE89087

This file was downloaded: " GSE89087_RAW.tar"

which was comprised of count data for the following:

GSM2358595	Control 1
GSM2358596	Uninfected red blood cells 1
GSM2358597	Infected red blood cells 1
GSM2358598	Lipopolysaccharides (LPS) 1
GSM2358599	Control 2
GSM2358600	Uninfected red blood cells 2
GSM2358601	Infected red blood cells 2
GSM2358602	Lipopolysaccharides (LPS) 2

But only the below (raw counts) was taken for our DE testing

GSM2358595	Control 1
GSM2358599	Control 2
GSM2358597	Infected red blood cells 1
GSM2358601	Infected red blood cells 2