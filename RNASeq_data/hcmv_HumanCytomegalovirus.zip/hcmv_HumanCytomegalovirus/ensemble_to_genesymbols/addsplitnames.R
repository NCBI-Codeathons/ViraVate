

hcmv <- read.delim("~/Desktop/hcmv_siP2Y2_counts.tsv", as.is = TRUE, sep = "\t", header = TRUE)
hcmv$splitname <- NA


for (i in 1:nrow(hcmv)){

	ensembleid <- as.character(hcmv[i,1])
	splitensemble <- strsplit(ensembleid, fixed = TRUE, ".")
	ensemble <- (splitensemble[[1]][1])
	hcmv$splitname[i] <- ensemble

}


	write.table(hcmv, file = "~/Desktop/siP2Y2splitnames.tsv", sep = "\t", append = TRUE, row.names = FALSE, col.names = TRUE, quote = FALSE)
