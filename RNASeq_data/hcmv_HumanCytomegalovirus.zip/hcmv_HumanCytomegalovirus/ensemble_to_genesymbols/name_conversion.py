import pandas as pd

ref_tb = pd.read_table('hcmv_siNT_ensembleids_wSYMBOL.tsv', sep = '\t')

#cnt_tb = raw_input('Enter the file name to process: ')
cnt_tb = 'splitnames.tsv'
mtx = pd.read_table(cnt_tb, sep = '\t')

# mtx['splitname'].isin(ref_tb['ensembleid'])

pd.merge(mtx, ref_tb, left_on='splitname', right_on='ensembleid', how='left').drop('ensembleid', axis=1).to_csv(cnt_tb.replace('.tsv', '_wSYMBOL.txt'), sep='\t', index=False)

