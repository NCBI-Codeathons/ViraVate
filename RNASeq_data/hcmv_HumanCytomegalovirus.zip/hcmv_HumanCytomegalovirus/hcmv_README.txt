# HCMV human cytomegalovirus DATASET INFO

From this page: 
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE130665

data download - supplemental file: "GSE130665_RAW.tar"

DE input was derived by:

two test groups from this dataset:

GSM3746612	siNT_mock_1
GSM3746613	siNT_mock_2
GSM3746616	siNT_HCMV_1
GSM3746617	siNT_HCMV_2

GSM3746614	siP2Y2_mock_1
GSM3746615	siP2Y2_mock_2
GSM3746618	siP2Y2_HCMV_1
GSM3746619	siP2Y2_HCMV_2

- two separate DE runs were performed based on HCMV strain (siNT & siP2Y2)
- these geneIDs were ensemble IDs, therefore, we had to find and link the associated gene symbol ID. The script that was used for the retrieval of the gene symbols can be found on this github repo ("convertid.R")

**there were a handful of CMV geneIDs that we can't covert. Those are placed into the file "hcmv_siNT_CMVgeneIDS"
