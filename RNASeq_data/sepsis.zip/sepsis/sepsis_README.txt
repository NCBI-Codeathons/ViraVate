# sepsis DATASET INFO

From this page: 
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE133822

This file was downloaded: "GSE133822_sepsis_count.txt.gz"

This dataset had lots and lots of data. We decided to use only the CD14 cell strain data after some PCA plots of the other two cell lines looked questionable (no clear separation).

There were some rows of the downlaoded data frame that appeared to have normalized counts and not raw counts (raw counts should be integers). We ran out of time to investigate so for the time being, we ran the DE test with those rows removed. 